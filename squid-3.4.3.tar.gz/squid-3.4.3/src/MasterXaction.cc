#include "squid.h"
#include "MasterXaction.h"

InstanceIdDefinitions(MasterXaction, "MXID_");
