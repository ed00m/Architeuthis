#ifndef SQUID_ESI_MODULE_H
#define SQUID_ESI_MODULE_H

namespace Esi
{

void Init();
void Clean();

} // namespace Esi

#endif /* SQUID_ESI_MODULE_H */
